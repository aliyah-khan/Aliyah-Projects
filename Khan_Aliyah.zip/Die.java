package assignemnt2;

import java.util.*;

public class Die {
	private int faceValue;
	
	//no argument constructor
	public Die() {
		this.faceValue = 1;
	}
	
	//getter and setteres
	public int getFaceValue() {
		return faceValue;
	}
	
	public void setFaceValue(int faceValue) {
		this.faceValue = faceValue;
	}
	
	//randomly rolling between 1 and 6 inclusove
	public void roll() {
		Random r = new Random();
		this.faceValue = r.nextInt(1,7);
	}

}
