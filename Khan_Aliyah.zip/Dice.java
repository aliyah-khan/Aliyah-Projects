package assignemnt2;
//aliyah khan al539963/4927759
//this code creates two dice objects and rolls them

import java.util.*;

public class Dice {
	private Die d1;
	private Die d2;

	//die objects with facevalue being initalized to 1
	public Dice() {
		d1 = new Die();
		d2 = new Die();
	}
	
	//adding the facevalues og both dice
	public int getFaceValue() {
		return d1.getFaceValue() + d2.getFaceValue();
	}
	
	public void roll() {
		d1.roll();
		d2.roll();
	}
}
