package assignemnt2;
//aliyah khan al539963/4927759
//this code rolls the dice objects 1000 times and takes data from each roll
//it then writes the results and creates a histogram with the data

public class Khan_Aliyah {
	
	//histogram method
	static void histogram(int [] freq) {
		System.out.printf("Graph\n");
		
		//y axis
		for (int i = 175; i >= 0; i -= 25) {
			System.out.printf("%3d|", i);
			
			//printing the data
			for (int j = 2; j <= 12; j++) {

				if (freq[j] <= i) {
					System.out.print("   ");
				}
				else {
					System.out.print("*  ");
				}
			}
			 System.out.println();
		}
		//x axis
		System.out.println("    --------------------------------");
        System.out.println("    2  3  4  5  6  7  8  9 10 11 12");
	}
	
	public static void main(String[] args) {
		Dice dice = new Dice();
		int [] freq = new int[13];
		
		//rolling and storing data
		for (int i = 0; i < 1000; i++) {
			int faceVals = dice.getFaceValue();
			dice.roll();
			freq[faceVals]++;
		}
		
		//printing data
		for (int i = 2; i <= 12; i++) {
			System.out.println("Number of " + i +"s are " + freq[i]);
		}
		histogram(freq);
	}

}
